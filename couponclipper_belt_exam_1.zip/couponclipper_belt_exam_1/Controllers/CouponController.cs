#pragma warning disable CS8618
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using couponclipper_belt_exam_1.Models;


namespace couponclipper_belt_exam_1.Controllers;

public class CouponController : Controller
{
    private readonly ILogger<CouponController> _logger;
    private MyContext _db;

    public CouponController(ILogger<CouponController> logger, MyContext context)
    {
        _logger = logger;
        _db = context;
    }
    // New User
    [HttpGet("coupons")]
    public IActionResult Index()
    {
        List<Coupon> allCoupons = _db.Coupons.Include(c => c.CouponTracker).ThenInclude(u => u.User).ToList();
        return View(allCoupons);
    }
    [HttpGet("/users/{userId}")]
    public IActionResult OneUser(int userId)
    {
        User? user = _db.Users.FirstOrDefault(u => u.UserId == userId);
        List<CouponAssociation>? allCoupons = _db.CouponAssociations.Include(ca => ca.Coupons).ThenInclude(u => u.UserId == userId).ToList();
        return View(user);
    }
    [HttpGet("coupons/new")]
    public IActionResult NewCoupon()
    {
        return View();
    }

    [HttpPost("coupons/create")]
    public IActionResult CreateCoupon(Coupon newCoupon)
    {
        if(!ModelState.IsValid)
        {
            return View("NewCoupon");
        }
        int? userId = HttpContext.Session.GetInt32("loggedUserId");
        if(userId != null)
        {
            newCoupon.UserId = (int)userId;
        }
            _db.Coupons.Add(newCoupon);
            _db.SaveChanges();
        return RedirectToAction("Index");
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}